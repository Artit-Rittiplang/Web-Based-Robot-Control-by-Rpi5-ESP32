from microdot import Microdot, Response
import asyncio
from html_page import HTML_PAGE
from serial_io import write_command  # import your serial helper

app = Microdot()
Response.default_content_type = 'text/html'

@app.route('/')
async def index(request):
    return HTML_PAGE

@app.route('/move_once')
async def move_once(request):
    l = request.args.get('l', '0')
    r = request.args.get('r', '0')
    t = request.args.get('t', '250')
    cmd = f"o {l} {r}\n"
    await asyncio.get_running_loop().run_in_executor(None, write_command, cmd)
    await asyncio.sleep(float(t)/1000)
    await asyncio.get_running_loop().run_in_executor(None, write_command, "o 0 0\n")
    return 'OK'

@app.route('/motor')
async def motor(request):
    l = request.args.get('l', '0')
    r = request.args.get('r', '0')
    cmd = f"o {l} {r}\n"
    resp = await asyncio.get_running_loop().run_in_executor(None, write_command, cmd)
    return resp

@app.route('/servo')
async def servo(request):
    sid = request.args.get('id', '0')
    angle = request.args.get('angle', '0')
    cmd = f"s {sid} {angle}\n"
    resp = await asyncio.get_running_loop().run_in_executor(None, write_command, cmd)
    return resp

@app.route('/encoders')
async def encoders(request):
    resp = await asyncio.get_running_loop().run_in_executor(None, write_command, "e\n")
    try:
        left, right = resp.split()
        return {'left': left, 'right': right}
    except:
        return {'left': 0, 'right': 0}

@app.route('/reset')
async def reset(request):
    await asyncio.get_running_loop().run_in_executor(None, write_command, "r\n")
    return 'OK'
