# html_page.py
HTML_PAGE = """<!DOCTYPE html>
<html>
<head>
<title>Robot Control (Step + Hold)</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2 { margin-top: 25px; }
.slider { width: 220px; }

.motor-panel { width: 350px; }

.dpad {
  display: grid;
  grid-template-columns: 80px 80px 80px;
  grid-template-rows: 50px 50px 50px;
  gap: 6px;
  margin-top: 15px;
}

.dpad button { width: 80px; height: 40px; }

.dpad .up { grid-column: 2; grid-row: 1; }
.dpad .left { grid-column: 1; grid-row: 2; }
.dpad .center { grid-column: 2; grid-row: 2; }
.dpad .right { grid-column: 3; grid-row: 2; }
.dpad .down { grid-column: 2; grid-row: 3; }
</style>
</head>

<body>
<h1>Robot Control (Step + Hold)</h1>

<h2>Motors</h2>
<div class="motor-panel">
PWM Left:
<input type="range" id="pwmL" min="0" max="255" value="150" class="slider">
<span id="pwmLval">150</span><br>

PWM Right:
<input type="range" id="pwmR" min="0" max="255" value="150" class="slider">
<span id="pwmRval">150</span><br><br>

Step time (ms):
<input type="number" id="stepTime" value="250">

<div class="dpad">
  <button class="up"
    onclick="stepMove('f')"
    onmousedown="startMove('f')"
    onmouseup="stopMove()"
    ontouchstart="startMove('f')"
    ontouchend="stopMove()">Forward</button>

  <button class="left"
    onclick="stepMove('l')"
    onmousedown="startMove('l')"
    onmouseup="stopMove()"
    ontouchstart="startMove('l')"
    ontouchend="stopMove()">Left</button>

  <button class="center" onclick="stopMove()">Stop</button>

  <button class="right"
    onclick="stepMove('r')"
    onmousedown="startMove('r')"
    onmouseup="stopMove()"
    ontouchstart="startMove('r')"
    ontouchend="stopMove()">Right</button>

  <button class="down"
    onclick="stepMove('b')"
    onmousedown="startMove('b')"
    onmouseup="stopMove()"
    ontouchstart="startMove('b')"
    ontouchend="stopMove()">Backward</button>
</div>
</div>
<h2>Servos</h2>
Servo 0:
<input type="range" id="s0" min="0" max="180" value="90" class="slider">
<span id="s0val">90</span><br>

Servo 1:
<input type="range" id="s1" min="0" max="180" value="90" class="slider">
<span id="s1val">90</span>

<h2>Encoders</h2>
Left: <span id="encL">0</span>  
Right: <span id="encR">0</span><br><br>
<button onclick="readEnc()">Read</button>
<button onclick="resetEnc()">Reset</button>

<script>
const pwmL = document.getElementById('pwmL');
const pwmR = document.getElementById('pwmR');
const pwmLval = document.getElementById('pwmLval');
const pwmRval = document.getElementById('pwmRval');
const stepTime = document.getElementById('stepTime');

pwmL.oninput = () => pwmLval.innerText = pwmL.value;
pwmR.oninput = () => pwmRval.innerText = pwmR.value;

let holdInterval = null;
let isHolding = false;

function calc(dir){
  let l = parseInt(pwmL.value);
  let r = parseInt(pwmR.value);
  if(dir==='b'){ l=-l; r=-r; }
  if(dir==='l'){ l=-l; }
  if(dir==='r'){ r=-r; }
  return {l,r};
}

// ---- STEP MOVE (CLICK) ----
function stepMove(dir){
  if(isHolding) return;
  let {l,r} = calc(dir);
  fetch(`/move_once?l=${l}&r=${r}&t=${stepTime.value}`);
}

// ---- CONTINUOUS MOVE (HOLD) ----
function startMove(dir){
  if(isHolding) return;
  isHolding = true;
  let {l,r} = calc(dir);
  fetch(`/motor?l=${l}&r=${r}`);
  holdInterval = setInterval(()=>{
    fetch(`/motor?l=${l}&r=${r}`);
  }, 100);
}

function stopMove(){
  if(holdInterval){
    clearInterval(holdInterval);
    holdInterval = null;
  }
  isHolding = false;
  fetch('/motor?l=0&r=0');
}

// ---- SERVOS ----
const s0 = document.getElementById('s0');
const s1 = document.getElementById('s1');
const s0val = document.getElementById('s0val');
const s1val = document.getElementById('s1val');

s0.oninput = () => {
  s0val.innerText = s0.value;
  fetch(`/servo?id=0&angle=${s0.value}`);
};

s1.oninput = () => {
  s1val.innerText = s1.value;
  fetch(`/servo?id=1&angle=${s1.value}`);
};

// ---- ENCODERS ----
function readEnc(){
  fetch('/encoders')
    .then(r => r.json())
    .then(d => {
      document.getElementById('encL').innerText = d.left;
      document.getElementById('encR').innerText = d.right;
    });
}

function resetEnc(){
  fetch('/reset');
}
</script>
</body>
</html>
"""