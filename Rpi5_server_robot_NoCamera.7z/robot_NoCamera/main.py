import asyncio
from routes import app 

async def main():
    await app.start_server(host='0.0.0.0', port=5000)

if __name__ == '__main__':
    asyncio.run(main())
